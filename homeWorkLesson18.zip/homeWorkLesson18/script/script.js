const products = [
    {
        productid: 1,
        categoryid: 1,
        title: "велосипед",
        price: 45000,
        count: 13,
        marks: [1, 4, 3, 5, 4, 3]
    },
    {
        productid: 2,
        categoryid: 1,
        title: "ролики",
        price: 25000,
        count: 22,
        marks: [3, 4, 3, 5]
    },
    {
        productid: 3,
        categoryid: 2,
        title: "стол",
        price: 10000,
        count: 7,
        marks: [4, 4, 5, 4, 5, 5, 5]
    },
    {
        productid: 4,
        categoryid: 3,
        title: "шкаф",
        price: 27000,
        count: 17,
        marks: [3, 2, 4, 3, 4, 3, 2, 4]
    },
    {
        productid: 5,
        categoryid: 3,
        title: "дверь",
        price: 7000,
        count: 1,
        marks: [2, 3, 1, 4, 3]
    }
];


// 1) создать функцию getProduct, которая в качестве аргумента получает id продукта и возвращает его

getProduct();

getTotalPrice();


function getProduct (productid){
    const result = products.map (({productid}) => productid);

    console.log(result);
    return(result);
};


// создать функцию getTotalPrice, которая не получает аргументов и возвращает общую сумму всех товаров. Произмедение кол-ва на цену и сумма этого значения у всех товаров. 

function getTotalPrice (){
    const new_result = products.map (({price, count}) => ({total_price: price * count})
    );

    const result_2 = new_result.reduce ((prev, item) => prev + item.total_price, 0);


    console.log(result_2);
    return (result_2);

}

console.log(getAvgMark(3));
console.log(getAvgMark(2));
console.log(getAvgMark(5));

function getAvgMark (productid){

    const result = products.filter (elem => elem.productid === productid);

    const marks = result.map(({marks}) => marks);
    let avg = marks[0].reduce((a,b) => a+b, 0);
    avg = avg / marks[0].length;

    return avg;
   
}

// создать функцию, getAvgMark  которая получает в качестве аргумента id продукта и возвращает среднюю оценку данного продукта.

console.log(getAvgMarkByCategory(1));
console.log(getAvgMarkByCategory(2));
console.log(getAvgMarkByCategory(3));


function getAvgMarkByCategory (categoryid){
const result = products.filter (elem => elem.categoryid === categoryid);

const marks = result.map(({marks}) => marks);
let avg = marks[0].reduce((a,b) => a+b, 0);
avg = avg / marks[0].length;

return avg;

}


// 4) создать функцию, getAvgMarkByCategory которая получает в качестве аргумента id категории и возвращает среднюю оценку всех товаров данной категории.

console.log (getLovelyProduct());

function getLovelyProduct(){

    const new_result = products.map(({productid, title, marks}) => (
        {productid, 
        title,
        marks: getAvgMark(productid)
    }) );

    const best_product = new_result.reduce((a,b) => a.marks > b.marks ? a : b);

    
return best_product.title;


};



// 5) создайте функцию getLovelyProduct которая возвращает продукт с наибольшим рейтингом